# Keep the Streak

A quiet, honest daily habit tracker: Now vs Today priorities, a 30-day heatmap per task,
an hours-based monthly progress chart, a visit streak counter, and a screen-time
self-awareness tracker. Your purpose/goal is asked once and shown as the daily heading.

All data is stored in the browser's localStorage — no backend, no sign-up. Each person
who opens the deployed link on their own device/browser gets their own private 30-day
history.

## Run locally

```
npm install
npm run dev
```

## Deploy (Netlify — easiest, ~2 minutes)

1. `npm install`
2. `npm run build` (creates a `dist/` folder)
3. Go to https://app.netlify.com/drop and drag the `dist/` folder in
4. Netlify gives you a live URL instantly — share that with friends

## Deploy (Vercel)

1. `npm install -g vercel`
2. `vercel` (from this project folder), follow the prompts

## Deploy (GitHub Pages via Netlify/Vercel + GitHub)

Push this folder to a GitHub repo, then connect that repo in Netlify or Vercel's
dashboard for automatic deploys on every push (build command: `npm run build`,
publish directory: `dist`).

## Notes on data

- Data lives in `localStorage` under the key `keep-the-streak:v1`, scoped per browser.
- Only the last 30 days are kept (older days are trimmed automatically) — matches the
  "one month" tracking window.
- If someone clears their browser data or switches devices, their history resets.
  Adding a real backend (e.g. MongoDB + Express, matching your MERN stack) would let
  the same account follow a person across devices — happy to build that next if you want it.
