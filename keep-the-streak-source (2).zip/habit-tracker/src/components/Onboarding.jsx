import { useState } from 'react';
import { Flame, ArrowRight } from 'lucide-react';

export default function Onboarding({ onComplete }) {
  const [name, setName] = useState('');
  const [purpose, setPurpose] = useState('');
  const [step, setStep] = useState(0);

  function handleNext(e) {
    e.preventDefault();
    if (step === 0) {
      if (!name.trim()) return;
      setStep(1);
      return;
    }
    if (!purpose.trim()) return;
    onComplete(name.trim(), purpose.trim());
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-md rise-in">
        <div className="mb-10 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-now-dim border border-now/30 mb-6 glow-now">
            <Flame size={30} className="text-now flame" fill="currentColor" fillOpacity={0.15} />
          </div>
          <p className="font-mono text-xs tracking-[0.35em] text-text-muted uppercase mb-3">Day one of many</p>
          <h1 className="font-display text-4xl sm:text-5xl font-semibold text-gradient leading-[1.1] italic">
            Keep the Streak
          </h1>
          <p className="text-text-muted mt-3 text-sm max-w-xs mx-auto">
            A quiet place to show up for yourself, one honest day at a time.
          </p>
        </div>

        <div className="flex items-center justify-center gap-2 mb-5">
          <span className={`h-1.5 rounded-full transition-all ${step === 0 ? 'w-8 bg-now' : 'w-1.5 bg-border'}`} />
          <span className={`h-1.5 rounded-full transition-all ${step === 1 ? 'w-8 bg-now' : 'w-1.5 bg-border'}`} />
        </div>

        <form
          onSubmit={handleNext}
          className="card border border-border rounded-3xl p-7 sm:p-9 space-y-5 shadow-2xl shadow-black/20"
        >
          {step === 0 ? (
            <>
              <div>
                <label className="block font-mono text-xs uppercase tracking-wider text-text-muted mb-2">
                  What should we call you?
                </label>
                <input
                  autoFocus
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  className="w-full bg-surface-2/80 border border-border rounded-xl px-4 py-3.5 text-text placeholder:text-text-muted/50 focus:outline-none focus:ring-2 focus:ring-now/60 focus:border-now/50 transition"
                />
              </div>
              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-now to-gold text-bg font-display font-semibold text-lg rounded-xl py-3.5 hover:brightness-110 active:scale-[0.99] transition-all shadow-lg shadow-now/20"
              >
                Continue <ArrowRight size={18} />
              </button>
            </>
          ) : (
            <>
              <div>
                <label className="block font-mono text-xs uppercase tracking-wider text-text-muted mb-2">
                  Why are you here, {name.split(' ')[0]}?
                </label>
                <p className="text-sm text-text-muted mb-3">
                  One sentence. This will greet you every single day, so make it honest.
                </p>
                <textarea
                  autoFocus
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="e.g. Become someone who shows up, even on bad days."
                  rows={3}
                  className="w-full bg-surface-2/80 border border-border rounded-xl px-4 py-3.5 text-text placeholder:text-text-muted/50 focus:outline-none focus:ring-2 focus:ring-now/60 focus:border-now/50 resize-none transition"
                />
              </div>
              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-now to-gold text-bg font-display font-semibold text-lg rounded-xl py-3.5 hover:brightness-110 active:scale-[0.99] transition-all shadow-lg shadow-now/20"
              >
                Start the streak <Flame size={18} fill="currentColor" />
              </button>
            </>
          )}
        </form>
      </div>
    </div>
  );
}
