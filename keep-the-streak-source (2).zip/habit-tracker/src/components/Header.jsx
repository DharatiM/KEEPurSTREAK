import { Flame, Pencil } from 'lucide-react';
import { useState } from 'react';

export default function Header({ user, streak, onEditPurpose }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(user.purpose);

  function save() {
    if (draft.trim()) onEditPurpose(draft.trim());
    setEditing(false);
  }

  const today = new Date().toLocaleDateString(undefined, {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  });

  return (
    <header className="relative border-b border-border overflow-hidden">
      <div
        className="absolute inset-0 opacity-60 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 600px 300px at 10% 0%, rgba(240,169,61,0.12), transparent 60%)',
        }}
      />
      <div className="relative max-w-3xl mx-auto px-5 sm:px-6 py-8 sm:py-10 flex items-start justify-between gap-4">
        <div className="min-w-0 fade-up">
          <p className="font-mono text-xs tracking-[0.25em] text-text-muted uppercase mb-3">{today}</p>
          {editing ? (
            <div className="flex items-start gap-2">
              <textarea
                autoFocus
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                rows={2}
                className="font-display italic text-2xl sm:text-3xl font-medium bg-surface-2/70 border border-border rounded-xl px-4 py-3 text-text w-full resize-none focus:outline-none focus:ring-2 focus:ring-now/60"
              />
              <button
                onClick={save}
                className="shrink-0 bg-now text-bg font-mono text-xs font-semibold rounded-lg px-3 py-2 mt-0.5 hover:brightness-110 transition"
              >
                Save
              </button>
            </div>
          ) : (
            <button onClick={() => setEditing(true)} className="group flex items-start gap-2 text-left">
              <h1 className="font-display italic text-2xl sm:text-3xl font-medium text-text leading-snug">
                "{user.purpose}"
              </h1>
              <Pencil size={14} className="mt-2 shrink-0 text-text-muted opacity-0 group-hover:opacity-100 transition" />
            </button>
          )}
          <p className="text-sm text-text-muted mt-2">
            Hey <span className="text-today font-medium">{user.name.split(' ')[0]}</span>, welcome back.
          </p>
        </div>

        <div className="shrink-0 flex flex-col items-center bg-surface-2/80 border border-now/30 rounded-2xl px-4 sm:px-5 py-4 glow-now fade-up">
          <Flame size={20} className="text-now mb-1 flame" fill="currentColor" fillOpacity={0.2} />
          <span className="font-display text-3xl font-semibold text-gradient leading-none">{streak}</span>
          <span className="font-mono text-[10px] uppercase tracking-wider text-text-muted mt-1.5">
            day{streak === 1 ? '' : 's'} strong
          </span>
        </div>
      </div>
    </header>
  );
}
