import { Clock, Target, Flame, ListChecks } from 'lucide-react';
import { lastNDayKeys } from '../utils/dates';
import HoursChart from './HoursChart';

function StatCard({ icon: Icon, label, value, sub, accent }) {
  return (
    <div className="bg-surface-2/60 border border-border rounded-xl px-4 py-3.5 hover:border-now/30 transition-colors">
      <div className="flex items-center gap-1.5 mb-2">
        <Icon size={13} className={accent} />
        <p className="font-mono text-[10px] uppercase tracking-wider text-text-muted">{label}</p>
      </div>
      <p className="font-display text-2xl font-semibold text-text">{value}</p>
      {sub && <p className="text-xs text-text-muted mt-0.5">{sub}</p>}
    </div>
  );
}

export default function MonthSummary({ tasks, state, streak }) {
  const keys = lastNDayKeys(30);

  let totalHours = 0;
  let totalCompletions = 0;
  let possible = 0;

  for (const key of keys) {
    const day = state.days[key];
    if (!day) continue;
    for (const task of tasks) {
      possible += 1;
      const log = day.taskLogs?.[task.id];
      if (log?.done) totalCompletions += 1;
      totalHours += log?.hours || 0;
    }
  }

  const completionRate = possible > 0 ? Math.round((totalCompletions / possible) * 100) : 0;

  return (
    <section className="card border border-border rounded-2xl p-5 sm:p-6 shadow-lg shadow-black/10">
      <h3 className="font-display italic text-xl font-medium text-text mb-5">This month's progress</h3>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-7">
        <StatCard icon={Clock} label="Total hours" value={Math.round(totalHours * 10) / 10} sub="last 30 days" accent="text-now" />
        <StatCard icon={Target} label="Completion" value={`${completionRate}%`} sub="of logged tasks" accent="text-complete" />
        <StatCard icon={Flame} label="Streak" value={streak} sub="days in a row" accent="text-social" />
        <StatCard icon={ListChecks} label="Tasks tracked" value={tasks.length} sub="active" accent="text-today" />
      </div>

      <HoursChart tasks={tasks} state={state} />
    </section>
  );
}
