import { lastNDayKeys, isToday, shortLabel } from '../utils/dates';

function intensityClass(hours, done) {
  if (!done) return 'bg-surface-2/60 border border-border';
  if (hours <= 0) return 'bg-complete/45 border border-complete/45';
  if (hours <= 1) return 'bg-complete/60 border border-complete/60';
  if (hours <= 2) return 'bg-complete/80 border border-complete/80';
  return 'bg-complete border border-complete shadow-[0_0_8px_rgba(82,201,122,0.5)]';
}

export default function Heatmap({ task, state }) {
  const keys = lastNDayKeys(30);

  return (
    <div>
      <div className="grid gap-[3px]" style={{ gridTemplateColumns: 'repeat(15, minmax(0, 1fr))' }}>
        {keys.map((key) => {
          const day = state.days[key];
          const log = day?.taskLogs?.[task.id];
          const done = !!log?.done;
          const hours = log?.hours || 0;
          const todayRing = isToday(key) ? 'ring-2 ring-gold ring-offset-1 ring-offset-surface' : '';
          return (
            <div
              key={key}
              title={`${shortLabel(key)}${done ? ` \u2014 ${hours > 0 ? hours + 'h' : 'done'}` : ''}`}
              className={`heat-cell aspect-square rounded-[4px] cursor-default ${intensityClass(hours, done)} ${todayRing}`}
            />
          );
        })}
      </div>
      <div className="flex justify-between mt-2 font-mono text-[10px] text-text-muted/80">
        <span>{shortLabel(keys[0])}</span>
        <span>{shortLabel(keys[keys.length - 1])}</span>
      </div>
    </div>
  );
}
