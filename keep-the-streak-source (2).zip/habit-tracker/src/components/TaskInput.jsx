import { useState } from 'react';
import { Plus, Zap, Sun } from 'lucide-react';

export default function TaskInput({ onAdd }) {
  const [name, setName] = useState('');
  const [type, setType] = useState('today');

  function submit(e) {
    e.preventDefault();
    if (!name.trim()) return;
    onAdd(name.trim(), type);
    setName('');
  }

  return (
    <form onSubmit={submit} className="card border border-border rounded-2xl p-3 flex flex-col sm:flex-row gap-2 mb-8 shadow-lg shadow-black/10">
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Add a task, e.g. Study DSA"
        className="flex-1 bg-transparent px-3 py-2.5 text-text placeholder:text-text-muted/60 focus:outline-none"
      />
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => setType('now')}
          className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl font-mono text-xs font-semibold uppercase tracking-wide border transition-all ${
            type === 'now'
              ? 'bg-gradient-to-r from-now to-gold text-bg border-now shadow-md shadow-now/20'
              : 'bg-transparent text-now border-now/30 hover:border-now/60'
          }`}
        >
          <Zap size={13} /> Now
        </button>
        <button
          type="button"
          onClick={() => setType('today')}
          className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl font-mono text-xs font-semibold uppercase tracking-wide border transition-all ${
            type === 'today'
              ? 'bg-today text-bg border-today shadow-md shadow-today/20'
              : 'bg-transparent text-today border-today/30 hover:border-today/60'
          }`}
        >
          <Sun size={13} /> Today
        </button>
        <button
          type="submit"
          className="flex items-center justify-center bg-surface-2 border border-border rounded-xl px-3.5 py-2.5 text-text hover:border-now/50 hover:text-now transition-all"
          aria-label="Add task"
        >
          <Plus size={18} />
        </button>
      </div>
    </form>
  );
}
