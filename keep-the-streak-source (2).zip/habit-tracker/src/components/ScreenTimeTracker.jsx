import { useState, useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, ReferenceLine } from 'recharts';
import { lastNDayKeys, shortLabel, todayKey } from '../utils/dates';
import { Smartphone, TrendingDown, TrendingUp } from 'lucide-react';

export default function ScreenTimeTracker({ state, onLog }) {
  const today = todayKey();
  const existing = state.days[today]?.socialMinutes;
  const [draft, setDraft] = useState(existing ?? '');

  const keys = lastNDayKeys(30);
  const data = keys.map((key) => ({
    label: shortLabel(key),
    minutes: state.days[key]?.socialMinutes ?? null,
  }));

  const logged = data.filter((d) => d.minutes !== null);
  const average = useMemo(() => {
    if (logged.length === 0) return null;
    return Math.round(logged.reduce((a, d) => a + d.minutes, 0) / logged.length);
  }, [logged]);

  const trend = useMemo(() => {
    if (logged.length < 4) return null;
    const half = Math.floor(logged.length / 2);
    const firstHalf = logged.slice(0, half);
    const secondHalf = logged.slice(half);
    const avg = (arr) => arr.reduce((a, d) => a + d.minutes, 0) / arr.length;
    return avg(secondHalf) - avg(firstHalf);
  }, [logged]);

  function submit(e) {
    e.preventDefault();
    onLog(draft);
  }

  return (
    <div className="card border border-border rounded-2xl p-5 sm:p-6 shadow-lg shadow-black/10">
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Smartphone size={16} className="text-social" />
          <h3 className="font-display italic text-xl font-medium text-text">Screen time honesty check</h3>
        </div>
        {trend !== null && (
          <span
            className={`flex items-center gap-1 font-mono text-xs px-2 py-1 rounded-md ${
              trend <= 0 ? 'text-complete bg-complete-dim' : 'text-social bg-social/15'
            }`}
          >
            {trend <= 0 ? <TrendingDown size={12} /> : <TrendingUp size={12} />}
            {trend <= 0 ? 'trending down' : 'trending up'}
          </span>
        )}
      </div>

      <form onSubmit={submit} className="flex items-center gap-2 mb-5">
        <input
          type="number"
          min="0"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Minutes on social media today"
          className="flex-1 bg-surface-2 border border-border rounded-lg px-3 py-2 text-sm text-text placeholder:text-text-muted/60 focus:outline-none focus:ring-2 focus:ring-social"
        />
        <button
          type="submit"
          className="font-mono text-xs uppercase tracking-wide bg-surface-2 border border-border rounded-lg px-3 py-2 text-text-muted hover:text-text transition"
        >
          Log
        </button>
      </form>

      {logged.length > 0 ? (
        <div className="h-56 -ml-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="#2E4A3A" strokeDasharray="3 3" vertical={false} />
              <XAxis
                dataKey="label"
                tick={{ fill: '#8FA89A', fontSize: 11, fontFamily: 'JetBrains Mono' }}
                axisLine={{ stroke: '#2E4A3A' }}
                tickLine={false}
                interval={Math.max(0, Math.floor(keys.length / 6))}
              />
              <YAxis
                tick={{ fill: '#8FA89A', fontSize: 11, fontFamily: 'JetBrains Mono' }}
                axisLine={{ stroke: '#2E4A3A' }}
                tickLine={false}
                width={32}
              />
              <Tooltip
                contentStyle={{ background: '#16281F', border: '1px solid #2E4A3A', borderRadius: 8, fontSize: 12 }}
                labelStyle={{ color: '#F2EDE1', fontFamily: 'JetBrains Mono' }}
                formatter={(v) => [`${v} min`, 'Social media']}
              />
              {average !== null && (
                <ReferenceLine
                  y={average}
                  stroke="#8FA89A"
                  strokeDasharray="4 4"
                  label={{ value: `avg ${average}m`, fill: '#8FA89A', fontSize: 10, position: 'insideTopRight' }}
                />
              )}
              <Line
                type="monotone"
                dataKey="minutes"
                stroke="#D3707A"
                strokeWidth={2.5}
                dot={{ r: 3, fill: '#D3707A' }}
                connectNulls
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <p className="text-sm text-text-muted">
          Log today's number to start the chart. Lower over time is the goal.
        </p>
      )}
    </div>
  );
}
