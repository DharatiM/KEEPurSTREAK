import { useState } from 'react';
import { Check, Zap, Sun, X } from 'lucide-react';
import Heatmap from './Heatmap';
import { todayKey } from '../utils/dates';

export default function TaskCard({ task, state, onToggle, onHours, onArchive }) {
  const today = todayKey();
  const todayLog = state.days[today]?.taskLogs?.[task.id];
  const done = !!todayLog?.done;
  const [hoursDraft, setHoursDraft] = useState(todayLog?.hours ? String(todayLog.hours) : '');

  const isNow = task.type === 'now';

  function submitHours(e) {
    e.preventDefault();
    onHours(task.id, hoursDraft);
  }

  return (
    <div
      className={`card rounded-2xl p-4 sm:p-5 border transition-all hover:shadow-xl hover:shadow-black/10 rise-in ${
        isNow ? 'border-now/30' : 'border-border'
      } ${isNow && !done ? 'pulse-now' : ''}`}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-start gap-3 min-w-0">
          <button
            onClick={() => onToggle(task.id)}
            aria-label={done ? 'Mark incomplete' : 'Mark complete'}
            className={`shrink-0 mt-0.5 w-7 h-7 rounded-full border-2 flex items-center justify-center transition-all ${
              done ? 'bg-gradient-to-br from-complete to-today border-complete scale-105' : 'bg-transparent hover:scale-110'
            }`}
            style={!done ? { borderColor: isNow ? 'var(--color-now)' : 'var(--color-today)' } : {}}
          >
            {done && <Check size={15} className="text-bg" strokeWidth={3} />}
          </button>
          <div className="min-w-0">
            <p className={`font-medium text-text leading-snug break-words ${done ? 'line-through text-text-muted' : ''}`}>
              {task.name}
            </p>
            <span
              className={`inline-flex items-center gap-1 mt-1.5 font-mono text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full ${
                isNow ? 'text-now bg-now-dim' : 'text-today bg-surface-2'
              }`}
            >
              {isNow ? <Zap size={10} /> : <Sun size={10} />}
              {isNow ? 'Now' : 'Today'}
            </span>
          </div>
        </div>
        <button
          onClick={() => onArchive(task.id)}
          aria-label="Remove task"
          className="shrink-0 text-text-muted hover:text-social transition-colors"
        >
          <X size={16} />
        </button>
      </div>

      <form onSubmit={submitHours} className="flex items-center gap-2 mb-4">
        <input
          type="number"
          min="0"
          step="0.25"
          value={hoursDraft}
          onChange={(e) => setHoursDraft(e.target.value)}
          placeholder="Hours today"
          className="w-28 bg-surface-2/70 border border-border rounded-lg px-3 py-1.5 text-sm text-text placeholder:text-text-muted/50 focus:outline-none focus:ring-2 focus:ring-now/50 transition"
        />
        <button
          type="submit"
          className="font-mono text-xs uppercase tracking-wide bg-surface-2/70 border border-border rounded-lg px-3 py-1.5 text-text-muted hover:text-now hover:border-now/40 transition-all"
        >
          Log
        </button>
      </form>

      <Heatmap task={task} state={state} />
    </div>
  );
}
