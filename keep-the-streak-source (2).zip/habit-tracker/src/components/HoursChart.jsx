import { AreaChart, Area, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { lastNDayKeys, shortLabel } from '../utils/dates';

const PALETTE = ['#6FA98C', '#52C97A', '#D3707A', '#7EA0C4', '#B888D6', '#E8C77A'];

export default function HoursChart({ tasks, state }) {
  const keys = lastNDayKeys(30);

  const data = keys.map((key) => {
    const day = state.days[key];
    const row = { label: shortLabel(key) };
    let total = 0;
    for (const task of tasks) {
      const hours = day?.taskLogs?.[task.id]?.hours || 0;
      row[task.id] = hours;
      total += hours;
    }
    row.total = Math.round(total * 100) / 100;
    return row;
  });

  if (tasks.length === 0) {
    return (
      <p className="text-sm text-text-muted">
        Add a task and start logging hours to see your progress here.
      </p>
    );
  }

  return (
    <div className="h-72 -ml-2">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="totalFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#F0A93D" stopOpacity={0.35} />
              <stop offset="100%" stopColor="#F0A93D" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="#2E4A3A" strokeDasharray="3 3" vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fill: '#8FA89A', fontSize: 11, fontFamily: 'JetBrains Mono' }}
            axisLine={{ stroke: '#2E4A3A' }}
            tickLine={false}
            interval={Math.max(0, Math.floor(keys.length / 6))}
          />
          <YAxis
            tick={{ fill: '#8FA89A', fontSize: 11, fontFamily: 'JetBrains Mono' }}
            axisLine={{ stroke: '#2E4A3A' }}
            tickLine={false}
            width={28}
          />
          <Tooltip
            contentStyle={{ background: '#16281F', border: '1px solid #2E4A3A', borderRadius: 10, fontSize: 12 }}
            labelStyle={{ color: '#F2EDE1', fontFamily: 'JetBrains Mono' }}
          />
          <Legend wrapperStyle={{ fontSize: 11, fontFamily: 'JetBrains Mono' }} />
          <Area
            type="monotone"
            dataKey="total"
            name="Total"
            stroke="#F0A93D"
            strokeWidth={2.5}
            fill="url(#totalFill)"
            dot={false}
          />
          {tasks.map((task, i) => (
            <Area
              key={task.id}
              type="monotone"
              dataKey={task.id}
              name={task.name}
              stroke={PALETTE[i % PALETTE.length]}
              strokeWidth={1.5}
              strokeOpacity={0.8}
              fill="transparent"
              dot={false}
            />
          ))}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
