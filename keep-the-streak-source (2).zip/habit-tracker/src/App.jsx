import { useEffect, useMemo, useState } from 'react';
import Onboarding from './components/Onboarding';
import Header from './components/Header';
import TaskInput from './components/TaskInput';
import TaskCard from './components/TaskCard';
import ScreenTimeTracker from './components/ScreenTimeTracker';
import MonthSummary from './components/MonthSummary';
import {
  loadState,
  saveState,
  ensureTodayEntry,
  setPurpose,
  updatePurpose,
  addTask,
  archiveTask,
  toggleTaskDone,
  setTaskHours,
  setSocialMinutes,
  computeStreak,
  activeTasks,
} from './utils/storage';

export default function App() {
  const [state, setState] = useState(() => ensureTodayEntry(loadState()));

  useEffect(() => {
    saveState(state);
  }, [state]);

  const streak = useMemo(() => computeStreak(state), [state]);
  const tasks = useMemo(() => activeTasks(state), [state]);
  const nowTasks = tasks.filter((t) => t.type === 'now');
  const todayTasks = tasks.filter((t) => t.type === 'today');

  if (!state.user) {
    return (
      <Onboarding
        onComplete={(name, purpose) => setState((s) => setPurpose(s, name, purpose))}
      />
    );
  }

  return (
    <div className="min-h-screen bg-bg pb-16">
      <Header
        user={state.user}
        streak={streak}
        onEditPurpose={(p) => setState((s) => updatePurpose(s, p))}
      />

      <main className="max-w-3xl mx-auto px-5 sm:px-6 py-8 space-y-10">
        <section>
          <TaskInput onAdd={(name, type) => setState((s) => addTask(s, name, type))} />

          {tasks.length === 0 && (
            <p className="text-sm text-text-muted card border border-border rounded-2xl px-5 py-6 text-center">
              Nothing here yet. Add your first task above — mark it <span className="text-now font-medium">Now</span> if
              it can't wait, or <span className="text-today font-medium">Today</span> if it just needs to happen before bed.
            </p>
          )}

          {nowTasks.length > 0 && (
            <div className="mb-7">
              <p className="font-mono text-xs uppercase tracking-[0.2em] text-now mb-3 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-now" /> Right now
              </p>
              <div className="space-y-3">
                {nowTasks.map((task) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    state={state}
                    onToggle={(id) => setState((s) => toggleTaskDone(s, id))}
                    onHours={(id, h) => setState((s) => setTaskHours(s, id, h))}
                    onArchive={(id) => setState((s) => archiveTask(s, id))}
                  />
                ))}
              </div>
            </div>
          )}

          {todayTasks.length > 0 && (
            <div>
              <p className="font-mono text-xs uppercase tracking-[0.2em] text-today mb-3 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-today" /> Sometime today
              </p>
              <div className="space-y-3">
                {todayTasks.map((task) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    state={state}
                    onToggle={(id) => setState((s) => toggleTaskDone(s, id))}
                    onHours={(id, h) => setState((s) => setTaskHours(s, id, h))}
                    onArchive={(id) => setState((s) => archiveTask(s, id))}
                  />
                ))}
              </div>
            </div>
          )}
        </section>

        <ScreenTimeTracker
          state={state}
          onLog={(minutes) => setState((s) => setSocialMinutes(s, minutes))}
        />

        <MonthSummary tasks={tasks} state={state} streak={streak} />
      </main>

      <footer className="max-w-3xl mx-auto px-5 sm:px-6 text-center">
        <p className="font-mono text-[10px] text-text-muted uppercase tracking-wider">
          Your data stays on this device
        </p>
      </footer>
    </div>
  );
}
