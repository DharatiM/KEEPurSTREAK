import { todayKey, lastNDayKeys, addDays, toKey } from './dates';

const STORAGE_KEY = 'keep-the-streak:v1';
const MAX_DAYS = 30;

function emptyState() {
  return {
    user: null, // { name, purpose, startDate }
    tasks: [],  // { id, name, type: 'now' | 'today', createdAt, archived }
    days: {},   // key -> { visited, socialMinutes, taskLogs: { [taskId]: { done, hours } } }
  };
}

export function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyState();
    const parsed = JSON.parse(raw);
    return { ...emptyState(), ...parsed };
  } catch {
    return emptyState();
  }
}

export function saveState(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

// Keep only the most recent MAX_DAYS entries in `days`.
export function trimToMonth(state) {
  const keep = new Set(lastNDayKeys(MAX_DAYS));
  const trimmedDays = {};
  for (const k of Object.keys(state.days)) {
    if (keep.has(k)) trimmedDays[k] = state.days[k];
  }
  return { ...state, days: trimmedDays };
}

export function ensureTodayEntry(state) {
  const key = todayKey();
  if (state.days[key]) return state;
  const next = {
    ...state,
    days: {
      ...state.days,
      [key]: { visited: true, socialMinutes: null, taskLogs: {} },
    },
  };
  return trimToMonth(next);
}

export function setPurpose(state, name, purpose) {
  return {
    ...state,
    user: { name, purpose, startDate: todayKey() },
  };
}

export function updatePurpose(state, purpose) {
  return { ...state, user: { ...state.user, purpose } };
}

export function addTask(state, name, type) {
  const task = {
    id: crypto.randomUUID(),
    name: name.trim(),
    type, // 'now' | 'today'
    createdAt: todayKey(),
    archived: false,
  };
  return { ...state, tasks: [...state.tasks, task] };
}

export function archiveTask(state, taskId) {
  return {
    ...state,
    tasks: state.tasks.map((t) => (t.id === taskId ? { ...t, archived: true } : t)),
  };
}

export function toggleTaskDone(state, taskId, dayKey = todayKey()) {
  const day = state.days[dayKey] || { visited: true, socialMinutes: null, taskLogs: {} };
  const existing = day.taskLogs[taskId] || { done: false, hours: 0 };
  const nextDone = !existing.done;
  const nextLog = { done: nextDone, hours: existing.hours || (nextDone ? existing.hours : 0) };
  const nextDay = { ...day, taskLogs: { ...day.taskLogs, [taskId]: nextLog } };
  return { ...state, days: { ...state.days, [dayKey]: nextDay } };
}

export function setTaskHours(state, taskId, hours, dayKey = todayKey()) {
  const day = state.days[dayKey] || { visited: true, socialMinutes: null, taskLogs: {} };
  const existing = day.taskLogs[taskId] || { done: false, hours: 0 };
  const safeHours = Math.max(0, Number(hours) || 0);
  const nextLog = { done: safeHours > 0 ? true : existing.done, hours: safeHours };
  const nextDay = { ...day, taskLogs: { ...day.taskLogs, [taskId]: nextLog } };
  return { ...state, days: { ...state.days, [dayKey]: nextDay } };
}

export function setSocialMinutes(state, minutes, dayKey = todayKey()) {
  const day = state.days[dayKey] || { visited: true, socialMinutes: null, taskLogs: {} };
  const safeMinutes = minutes === '' || minutes === null ? null : Math.max(0, Number(minutes) || 0);
  const nextDay = { ...day, socialMinutes: safeMinutes };
  return { ...state, days: { ...state.days, [dayKey]: nextDay } };
}

// Streak = consecutive days ending today where the user visited the app.
export function computeStreak(state) {
  let streak = 0;
  let cursor = new Date();
  // If today not yet visited, streak still counts prior consecutive days,
  // but since we call ensureTodayEntry on load, today will always be visited.
  for (;;) {
    const key = toKey(cursor);
    const day = state.days[key];
    if (day && day.visited) {
      streak += 1;
      cursor = addDays(cursor, -1);
    } else {
      break;
    }
  }
  return streak;
}

export function getDay(state, dayKey) {
  return state.days[dayKey] || { visited: false, socialMinutes: null, taskLogs: {} };
}

export function activeTasks(state) {
  return state.tasks.filter((t) => !t.archived);
}
